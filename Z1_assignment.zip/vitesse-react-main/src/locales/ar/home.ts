export default {
    "hello": "السلام عليكم",
    "welcome": "مرحبا بكم",
    "template_desc": "قالب حديث مبني بواسطة Vite و React",
    "template_sub_desc":" هذا القالب مبني على Vite و React.js و Tailwind CSS باستخدام محرك UnoCSS",
    "dashboard": "لوحة التحكم",
    "github": "جيت هاب",
    "view_github": "مشاهدة على Github",
    "dark_mode_desc": "هذا القالب مصمم بشكل داكن أيضا",
    features:'ميزات',
}