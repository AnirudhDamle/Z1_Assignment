export default {
    "dashboard": "لوحة القيادة",
    "components": "المكونات",
    "team": "الفريق",
    "projects": "المشاريع",
    "calendar": "التقويم",
    "reports": "التقارير",
}