export default {
    "hello": "Hello !",
    "welcome": "Welcome !",
    "template_desc":"Modern Vite Starter Template for React",
    "template_sub_desc":"This template is built on top of Vite, React.js and Tailwind CSS using UnoCSS engine",
    "dashboard": "Dashboard",
    "github": "Github",
    "view_github": "View on Github",
    "dark_mode_desc": "This template is designed also with dark mode support",
    features:'Features',
}