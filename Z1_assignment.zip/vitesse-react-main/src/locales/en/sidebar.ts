export default{
    "dashboard": "Dashboard",
    "components": "Components",
    "team": "Team",
    "projects": "Projects",
    "calendar": "Calendar",
    "reports": "Reports",
}